﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;

namespace medicalProject.Member
{
    public partial class _AprioriAlgorithm : System.Web.UI.Page
    {
        Dictionary<string, double> DictionaryAllFrequentItems = new Dictionary<string, double>();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {                
                PatternPrediction();
            }
            catch
            {

            }
        }

       

        #region -- Algorithm Steps ---

        private void Solve()
        {
            double MinSupport = 0.1;
            double MinConfidence = 0.5;
            ////Scan the transaction database to get the support S of each 1-itemset,
            Dictionary<string, double> DictionaryFrequentItemsList1 = GetList1FrequentItems(MinSupport);
            Dictionary<string, double> DictionaryFrequentItemsMain = DictionaryFrequentItemsList1;
            Dictionary<string, double> DictionaryCandidates = new Dictionary<string, double>();
            do
            {
                DictionaryCandidates = GenerateCandidates(DictionaryFrequentItemsMain);
                DictionaryFrequentItemsMain = GetFrequentItems(DictionaryCandidates, MinSupport);
            }
            while (DictionaryCandidates.Count != 0);
            //MessageBox.Show("Hello");
            List<ClassRules> RulesList = GenerateRules();
            List<ClassRules> StrongRules = GetStrongRules(MinConfidence, RulesList);
            Result(DictionaryAllFrequentItems, StrongRules);
            //SolutionObject.ShowDialog();
        }

        //FUNCTION TO GET THE FIRST LIST OF FREQUENT ITEMS OCCURING IN THE SET OF TRANSACTIONS
        private Dictionary<string, double> GetList1FrequentItems(double MinSupport)
        {
            Dictionary<string, double> DictionaryFrequentItemsReturn = new Dictionary<string, double>();
            for (int i = 0; i < lv_Items.Items.Count; i++)
            {
                double Support = GetSupport(lv_Items.Items[i].Text.ToString());
                if ((Support / (double)(lv_Transactions.Items.Count) >= MinSupport))
                {
                    DictionaryFrequentItemsReturn.Add(lv_Items.Items[i].Text.ToString(), Support);

                    DictionaryAllFrequentItems.Add(lv_Items.Items[i].Text.ToString(), Support);
                }
            }
            return DictionaryFrequentItemsReturn;
        }

        //FUNCTION GETS THE SUPPORT FOR EACH INDIVIDUAL ITEMS IN SET OF TRANSACTIONS
        private double GetSupport(string GeneratedCandidate)
        {
            double SupportReturn = 0;

            string[] AllTransactions = new string[lv_Transactions.Items.Count];
            for (int i = 0; i < lv_Transactions.Items.Count; i++)
            {
                AllTransactions[i] = lv_Transactions.Items[i].Text.ToString();
            }
            foreach (string Transaction in AllTransactions)
            {
                if (IsSubstring(GeneratedCandidate, Transaction))
                {
                    SupportReturn++;
                }
            }

            return SupportReturn;
        }

        //FUNCTION TO CHECK IF THE ITEM EXISTS IN A GIVEN TRANSACTION
        private bool IsSubstring(string Child, string Parent)
        {
            string[] TransactionArray = Child.Split(',');
            //string value = null;
            foreach (string Item in TransactionArray)
            {
                if (!Parent.Contains(Item))
                    return false;
            }
            return true;
        }

        //FUNCTION TO GENERATE CANDIDATES FROM THE FREQUENT ITEM LIST
        //GET THE FIRST ITEM - ADD THE NEXT ITEM - SORT ITEMS
        //GET THE CANDIDATES EXCLUDING THE SIMILAR ITEMS
        //GET SUPPORT AND ADD TO DICTIONARY

        private Dictionary<string, double> GenerateCandidates(Dictionary<string, double> MainFrequentItems)
        {
            Dictionary<string, double> DictionaryCandidatesReturn = new Dictionary<string, double>();
            for (int i = 0; i < MainFrequentItems.Count - 1; i++)
            {
                string[] FirstItem = Alphabetize(MainFrequentItems.Keys.ElementAt(i));
                string FirstItemString = null;
                for (int k = 0; k < FirstItem.Length; k++)
                {
                    FirstItemString += FirstItem[k].ToString() + ",";
                }
                FirstItemString = FirstItemString.Remove(FirstItemString.Length - 1);
                for (int j = i + 1; j < MainFrequentItems.Count; j++)
                {
                    string[] SecondItem = Alphabetize(MainFrequentItems.Keys.ElementAt(j));
                    string SecondItemString = null;
                    for (int l = 0; l < SecondItem.Length; l++)
                    {
                        SecondItemString += SecondItem[l].ToString() + ",";
                    }
                    SecondItemString = SecondItemString.Remove(SecondItemString.Length - 1);
                    string GeneratedCandidate = GetCandidate(FirstItemString, SecondItemString);
                    //MessageBox.Show("A " + GeneratedCandidate);
                    //string GeneratedCandidate = GetCandidate("Brush,Lace,Socks,Shoe", "Brush,Lace,Socks,Polish");
                    if (GeneratedCandidate != string.Empty)
                    {
                        string[] CandidateArray = Alphabetize(GeneratedCandidate);
                        GeneratedCandidate = "";
                        for (int m = 0; m < CandidateArray.Length; m++)
                        {
                            GeneratedCandidate += CandidateArray[m].ToString() + ",";
                        }

                        GeneratedCandidate = GeneratedCandidate.Remove(GeneratedCandidate.Length - 1);
                        double Support = GetSupport(GeneratedCandidate);
                        DictionaryCandidatesReturn.Add(GeneratedCandidate, Support);
                    }
                }
            }
            return DictionaryCandidatesReturn;
        }

        //FUNCTION TO SORT THE GIVEN ITEMS IN ALPHABETICAL ORDER
        private string[] Alphabetize(string Token)
        {
            // Convert to char array, then sort and return
            string[] TokenArray = Token.Split(',');
            Array.Sort(TokenArray);
            return TokenArray;
        }

        //FUNCTION TO GET CANDIDATE EXCLUDING THE SIMILAR ITEMS.
        private string GetCandidate(string FirstItemString, string SecondItemString)
        {
            string CandidateJoin = null;
            if (FirstItemString.Contains(',') || SecondItemString.Contains(','))
            {
                string[] First = FirstItemString.Split(',');
                string[] Second = SecondItemString.Split(',');
                if (First[0] != Second[0])
                {
                    return string.Empty;
                }
                else
                {
                    string firstString = FirstItemString.Substring(0, FirstItemString.LastIndexOf(','));
                    string secondString = SecondItemString.Substring(0, SecondItemString.LastIndexOf(','));
                    if (firstString == secondString)
                    {
                        return FirstItemString + SecondItemString.Substring(SecondItemString.LastIndexOf(','));
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
                ////int i=0;
                ////int x = 0;
                ////for ( i = 0; i < First.Length; i++)
                ////{
                ////    if (Second.Length > i)
                ////    {
                ////        if (First[i] == Second[i])
                ////        {
                ////            CandidateJoin = CandidateJoin + "," + First[i];
                ////            x = i;
                ////        }
                ////    }
                ////}

                ////for (i=x+1; i < First.Length; i++)
                ////{
                ////    CandidateJoin = CandidateJoin + "," + First[i];
                ////}
                ////for (x=x+1; x < Second.Length; x++)
                ////{
                ////    CandidateJoin = CandidateJoin + "," + Second[x];
                ////}
                ////return CandidateJoin.Substring(1);


                //string FirstSubString = FirstItemString.Substring(0, FirstItemString.IndexOf(','));
                //string SecondSubString = SecondItemString.Substring(0, SecondItemString.IndexOf(','));
                //if (FirstSubString == SecondSubString)
                //{
                //    return FirstItemString + SecondItemString.Substring(SecondItemString.IndexOf(','));
                //}
                //else
                //    return string.Empty;
            }
            else
            {
                return FirstItemString + "," + SecondItemString;
            }
        }

        //FUNCTION TO GET FREQUENT ITEMS THROUGH GIVEN SUPPORT
        private Dictionary<string, double> GetFrequentItems(Dictionary<string, double> CandidatesDictionary, double MinimumSupport)
        {
            Dictionary<string, double> FrequentReturn = new Dictionary<string, double>();
            for (int i = CandidatesDictionary.Count - 1; i >= 0; i--)
            {
                string Item = CandidatesDictionary.Keys.ElementAt(i);
                double Support = CandidatesDictionary[Item];
                if ((Support / (double)(lv_Transactions.Items.Count) >= MinimumSupport))
                {
                    FrequentReturn.Add(Item, Support);
                    DictionaryAllFrequentItems.Add(Item, Support);
                }
            }
            return FrequentReturn;
        }

        //FUNCTION TO GENERATE RULES
        private List<ClassRules> GenerateRules()
        {
            List<ClassRules> RulesReturnList = new List<ClassRules>();
            foreach (string Item in DictionaryAllFrequentItems.Keys)
            {
                string[] ItemArray = Item.Split(',');
                if (ItemArray.Length > 1)
                {
                    int MaxCombinationLength = ItemArray.Length / 2;
                    GenerateCombination(Item, MaxCombinationLength, ref RulesReturnList);
                }
            }
            return RulesReturnList;
        }

        private void GenerateCombination(string Item, int CombinationLength, ref List<ClassRules> RulesReturnList)
        {
            string[] ItemArray = Item.Split(',');
            int ItemLength = ItemArray.Length;
            if (ItemLength == 2)
            {
                AddItem(ItemArray[0].ToString(), Item, ref RulesReturnList);
                return;
            }
            else if (ItemLength == 3)
            {
                for (int i = 0; i < ItemLength; i++)
                {
                    AddItem(ItemArray[i].ToString(), Item, ref RulesReturnList);
                }
                return;
            }
            else
            {
                for (int i = 0; i < ItemLength; i++)
                {
                    GetCombinationRecursive(ItemArray[i].ToString(), Item, CombinationLength, ref RulesReturnList);
                }
            }
        }

        private void AddItem(string Combination, string Item, ref List<ClassRules> RulesReturnList)
        {
            string Remaining = GetRemaining(Combination, Item);
            ClassRules Rule = new ClassRules(Combination, Remaining, 0);
            RulesReturnList.Add(Rule);
        }

        private string GetCombinationRecursive(string Combination, string Item, int CombinationLength, ref List<ClassRules> RulesReturnList)
        {
            AddItem(Combination, Item, ref RulesReturnList);
            string LastTokenItem = Combination;
            if (Combination.Contains(','))
                LastTokenItem = Combination.Substring(Combination.LastIndexOf(',') + 1);

            string NextItem = null; ;
            string LastItem = Item.Substring(Item.LastIndexOf(',') + 1);
            if (Combination.Split(',').Length == CombinationLength)
            {
                if (LastTokenItem != LastItem)
                {
                    string TempCombination = null;
                    foreach (string str in Combination.Split(','))
                    {
                        if (str != LastTokenItem)
                        {
                            TempCombination = TempCombination + "," + str;
                        }
                    }
                    Combination = TempCombination.Substring(1);
                    string[] strs = Item.Split(',');
                    for (int i = 0; i < strs.Length; i++)
                    {
                        if (strs[i] == LastTokenItem)
                        {
                            NextItem = strs[i + 1];
                        }
                    }
                    //Combination = Combination.Remove(nLastTokenCharcaterIndex, 1);
                    //NextItem = Item[nLastTokenCharcaterIndexInParent + 1];
                    string strNewToken = Combination + "," + NextItem;
                    return (GetCombinationRecursive(strNewToken, Item, CombinationLength, ref RulesReturnList));
                }
                else
                {
                    return string.Empty;
                }
            }
            else
            {
                if (Combination != LastItem.ToString())
                {
                    string[] strs = Item.Split(',');
                    for (int i = 0; i < strs.Length; i++)
                    {                        
                        if (strs[i] == LastTokenItem)
                        {
                            NextItem = strs[i + 1];
                        }
                    }
                    //NextItem = Item[nLastTokenCharcaterIndexInParent + 1];
                    string strNewToken = Combination + "," + NextItem;
                    return (GetCombinationRecursive(strNewToken, Item, CombinationLength, ref RulesReturnList));
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string GetRemaining(string Child, string Parent)
        {
            string[] childArray = Child.Split(',');
            for (int i = 0; i < childArray.Length; i++)
            {
                string Remaining = null;
                string[] ParentArray = Parent.Split(',');
                for (int j = 0; j < ParentArray.Length; j++)
                {
                    if (childArray[i] != ParentArray[j])
                    {
                        Remaining = Remaining + "," + ParentArray[j];
                    }
                }
                if (Remaining.Contains(','))
                    Parent = Remaining.Substring(1);
                else
                    Parent = Remaining;
            }
            return Parent;
        }

        private List<ClassRules> GetStrongRules(double MinConfidence, List<ClassRules> RulesList)
        {
            List<ClassRules> StrongRulesReturn = new List<ClassRules>();
            foreach (ClassRules Rule in RulesList)
            {
                string[] XY = Alphabetize(Rule.X + "," + Rule.Y);
                string XYString = null;
                for (int i = 0; i < XY.Length; i++)
                {
                    XYString += XY[i] + ",";
                }
                XYString = XYString.Remove(XYString.Length - 1);
                AddStrongRule(Rule, XYString, ref StrongRulesReturn, MinConfidence);
            }
            StrongRulesReturn.Sort();
            return StrongRulesReturn;
        }

        private void AddStrongRule(ClassRules Rule, string XY, ref List<ClassRules> StrongRulesReturn, double MinConfidence)
        {
            double Confidence = GetConfidence(Rule.X, XY);
            ClassRules NewRule;
            if (Confidence >= MinConfidence)
            {
                NewRule = new ClassRules(Rule.X, Rule.Y, Confidence);
                StrongRulesReturn.Add(NewRule);
            }
            Confidence = GetConfidence(Rule.Y, XY);
            if (Confidence >= MinConfidence)
            {
                NewRule = new ClassRules(Rule.Y, Rule.X, Confidence);
                StrongRulesReturn.Add(NewRule);
            }
        }

        private double GetConfidence(string X, string XY)
        {
            double Support_X, Support_XY;
            Support_X = DictionaryAllFrequentItems[X];
            Support_XY = DictionaryAllFrequentItems[XY];
            return Support_XY / Support_X;
        }

        public void Result(Dictionary<string, double> AllFrequentItems, List<ClassRules> StrongRulesList)
        {
            LoadFrequentItems(AllFrequentItems);
            LoadRules(StrongRulesList);
        }

        private void LoadFrequentItems(Dictionary<string, double> AllFrequentItems)
        {

            foreach (string Item in AllFrequentItems.Keys)
            {
                ListItem items = new ListItem(Item);
                ListBox1.Items.Add(items);
            }
        }

        private void LoadRules(List<ClassRules> StrongRulesList)
        {            
            Table4.Rows.Clear();

            Table4.BorderStyle = BorderStyle.Double;
            Table4.GridLines = GridLines.Both;
            Table4.BorderColor = System.Drawing.Color.DarkGray;

            TableRow mainrow = new TableRow();
            mainrow.HorizontalAlign = HorizontalAlign.Left;
            mainrow.Height = 30;
            mainrow.ForeColor = System.Drawing.Color.White;
            mainrow.Font.Bold = true;
            mainrow.BackColor = System.Drawing.Color.ForestGreen;

            //Oncologist, Neurologist, Cardiologist, Urologist,  Gynecologist,  Orthopedics,  Surgeon,  Physician, Beds,  ICU,  Nurses,  
            //Dentist,  Pharmacy, TechnicalNurses,  MortalityRate

            TableHeaderCell cell1 = new TableHeaderCell();
            cell1.Width = 250;
            cell1.Text = "Rule X";
            mainrow.Controls.Add(cell1);

            TableHeaderCell cell3 = new TableHeaderCell();
            cell3.Width = 100;
            cell3.Text = "->";
            mainrow.Controls.Add(cell3);

            TableHeaderCell cell4 = new TableHeaderCell();
            cell4.Width = 250;
            cell4.Text = "Rule Y";
            mainrow.Controls.Add(cell4);

            TableHeaderCell cell2 = new TableHeaderCell();
            cell2.Text = "Confidence";
            mainrow.Controls.Add(cell2);
            System.Threading.Thread.Sleep(2000);
            Table4.Controls.Add(mainrow);
            //TableHeaderCell cell1 = new TableHeaderCell();
            //cell1.Width = 250;
            //cell1.Text = "Temp, Rainfall, PH, Nitrogen Vs Paddy Yield";
            //mainrow.Controls.Add(cell1);

            //TableHeaderCell cell3 = new TableHeaderCell();
            //cell3.Width = 100;
            //cell3.Text = "->";
            //mainrow.Controls.Add(cell3);

            //TableHeaderCell cell4 = new TableHeaderCell();
            //cell4.Width = 250;
            //cell4.Text = "Rule Y";
            //mainrow.Controls.Add(cell4);

            //TableHeaderCell cell2 = new TableHeaderCell();
            //cell2.Text = "Confidence";
            //mainrow.Controls.Add(cell2);
            System.Threading.Thread.Sleep(5000);
            Table4.Controls.Add(mainrow);

            int i = 0;

            if (StrongRulesList.Count > 0)
            {
                //Session["patterns"] = StrongRulesList;
                ListBox2.Items.Clear();
               
                foreach (ClassRules Rule in StrongRulesList)
                {
                    if (Rule.Y.Contains(','))
                    {
                        string[] _SM = Rule.Y.Split(',');

                        if (_SM.Contains("MortalityRate_Low") || _SM.Contains("MortalityRate_Medium") || _SM.Contains("MortalityRate_High"))
                        {
                            for (int j = 0; j < _SM.Length; j++)
                            {
                                if (_SM[j].Contains("MortalityRate_Low") || _SM[j].Contains("MortalityRate_Medium") || _SM[j].Contains("MortalityRate_High"))
                                {
                                    ListItem items = new ListItem(Rule.X + "->" + Rule.Y);
                                    ListBox2.Items.Add(items);

                                    TableRow row = new TableRow();

                                    TableCell cellX1 = new TableCell();
                                    cellX1.Text = Rule.X;
                                    row.Controls.Add(cellX1);

                                    TableCell cell_rule2 = new TableCell();
                                    //cell_rule2.HorizontalAlign = HorizontalAlign.Center;
                                    cell_rule2.Width = 100;
                                    cell_rule2.Text = "->";
                                    row.Controls.Add(cell_rule2);


                                    TableCell cellY1 = new TableCell();
                                    cellY1.Text = _SM[j];
                                    row.Controls.Add(cellY1);

                                    TableCell cell_confidence = new TableCell();
                                    cell_confidence.HorizontalAlign = HorizontalAlign.Left;
                                    cell_confidence.Width = 100;
                                    cell_confidence.Text = String.Format("{0:0.00}", (Rule.Confidence * 100)) + "%";
                                    row.Controls.Add(cell_confidence);

                                    Table4.Controls.Add(row);
                                }
                            }
                        }

                    }
                    else
                    {
                        if (Rule.Y.Contains("MortalityRate_Low") || Rule.Y.Contains("MortalityRate_Medium") || Rule.Y.Contains("MortalityRate_High"))
                        {
                            ListItem items = new ListItem(Rule.X + "->" + Rule.Y);
                            ListBox2.Items.Add(items);

                            TableRow row = new TableRow();

                            TableCell cellX1 = new TableCell();
                            cellX1.Text = Rule.X;
                            row.Controls.Add(cellX1);

                            TableCell cell_rule2 = new TableCell();
                            //cell_rule2.HorizontalAlign = HorizontalAlign.Center;
                            cell_rule2.Width = 100;
                            cell_rule2.Text = "->";
                            row.Controls.Add(cell_rule2);


                            TableCell cellY1 = new TableCell();
                            cellY1.Text = Rule.Y;
                            row.Controls.Add(cellY1);

                            TableCell cell_confidence = new TableCell();
                            cell_confidence.HorizontalAlign = HorizontalAlign.Left;
                            cell_confidence.Width = 100;
                            cell_confidence.Text = String.Format("{0:0.00}", (Rule.Confidence * 100)) + "%";
                            row.Controls.Add(cell_confidence);

                            Table4.Controls.Add(row);
                        }
                    }
                                        
                    ++i;                                      
                }
            }
            else
            {
                Table4.Rows.Clear();
                Table4.GridLines = GridLines.None;

                TableHeaderRow row = new TableHeaderRow();
                TableHeaderCell cell = new TableHeaderCell();
                cell.HorizontalAlign = HorizontalAlign.Center;
                cell.Font.Bold = true;
                cell.ForeColor = System.Drawing.Color.Red;
                cell.ColumnSpan = 5;
                cell.Text = "No Pattrens Found for the Input!!!";
                row.Controls.Add(cell);

                Table4.Controls.Add(row);
            }
        }

        #endregion

        private void PatternPrediction()
        {
            try
            {
                string _time;

                BLL obj = new BLL();

                DataTable tabDataset = new DataTable();

                tabDataset = obj.GetDatasetByHospital(Session["ICId"].ToString());

                lv_Transactions.Items.Clear();
                lv_Items.Items.Clear();
                DictionaryAllFrequentItems.Clear();
                ListBox1.Items.Clear();
                ListBox2.Items.Clear();

                if (tabDataset.Rows.Count > 0)
                {
                    for (int i = 0; i < tabDataset.Rows.Count; i++)
                    {
                        //Oncologist, Neurologist, Cardiologist, Urologist,  Gynecologist,  Orthopedics,  Surgeon,  Physician,
                        //Beds,  ICU,  Nurses,  Dentist,  Pharmacy, TechnicalNurses,  MortalityRate
                        string _data = null;

                        //if (tabDataset.Rows[i]["Oncologist"].ToString().Equals(""))
                        //{

                        //}
                        //else
                        //{
                        //    //Oncologist
                        //    double _Oncologist = double.Parse(tabDataset.Rows[i]["Oncologist"].ToString());
                        //    string _OncologistStatus = null;

                        //    if (_Oncologist <= 5)
                        //    {
                        //        _OncologistStatus = "Oncologist_Low";
                        //    }
                        //    else if (_Oncologist > 5  && _Oncologist <= 10)
                        //    {
                        //        _OncologistStatus = "Oncologist_Medium";
                        //    }
                        //    else if (_Oncologist > 10)
                        //    {
                        //        _OncologistStatus = "Oncologist_High";
                        //    }

                        //    _data += _OncologistStatus + ",";
                        //}

                        if (tabDataset.Rows[i]["Neurologist"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Neurologist
                            double _Neurologist = double.Parse(tabDataset.Rows[i]["Neurologist"].ToString());
                            string _NeurologistStatus = null;

                            if (_Neurologist <= 5)
                            {
                                _NeurologistStatus = "Neurologist_Low";
                            }
                            else if (_Neurologist > 5 && _Neurologist <= 10)
                            {
                                _NeurologistStatus = "Neurologist_Medium";
                            }
                            else if (_Neurologist > 10)
                            {
                                _NeurologistStatus = "Neurologist_High";
                            }

                            _data += _NeurologistStatus + ",";
                        }

                        if (tabDataset.Rows[i]["Cardiologist"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Cardiologist
                            double _Cardiologist = double.Parse(tabDataset.Rows[i]["Cardiologist"].ToString());
                            string _CardiologistStatus = null;

                            if (_Cardiologist <= 5)
                            {
                                _CardiologistStatus = "Cardiologist_Low";
                            }
                            else if (_Cardiologist > 5 && _Cardiologist <= 10)
                            {
                                _CardiologistStatus = "Cardiologist_Medium";
                            }
                            else if (_Cardiologist > 10)
                            {
                                _CardiologistStatus = "Cardiologist_High";
                            }

                            _data += _CardiologistStatus + ",";
                        }

                        //if (tabDataset.Rows[i]["Urologist"].ToString().Equals(""))
                        //{

                        //}
                        //else
                        //{
                        //    //Urologist
                        //    double _Urologist = double.Parse(tabDataset.Rows[i]["Urologist"].ToString());
                        //    string _UrologistStatus = null;

                        //    if (_Urologist <= 5)
                        //    {
                        //        _UrologistStatus = "Urologist_Low";
                        //    }
                        //    else if (_Urologist > 5 && _Urologist <= 10)
                        //    {
                        //        _UrologistStatus = "Urologist_Medium";
                        //    }
                        //    else if (_Urologist > 10)
                        //    {
                        //        _UrologistStatus = "Urologist_High";
                        //    }

                        //    _data += _UrologistStatus + ",";
                        //}

                        if (tabDataset.Rows[i]["Gynecologist"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Gynecologist
                            double _Gynecologist = double.Parse(tabDataset.Rows[i]["Gynecologist"].ToString());
                            string _GynecologistStatus = null;

                            if (_Gynecologist <= 5)
                            {
                                _GynecologistStatus = "Gynecologist_Low";
                            }
                            else if (_Gynecologist > 5 && _Gynecologist <= 10)
                            {
                                _GynecologistStatus = "Gynecologist_Medium";
                            }
                            else if (_Gynecologist > 10)
                            {
                                _GynecologistStatus = "Gynecologist_High";
                            }

                            _data += _GynecologistStatus + ",";
                        }

                        if (tabDataset.Rows[i]["Orthopedics"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Neurologist
                            double _Orthopedics = double.Parse(tabDataset.Rows[i]["Orthopedics"].ToString());
                            string _OrthopedicsStatus = null;

                            if (_Orthopedics <= 5)
                            {
                                _OrthopedicsStatus = "Orthopedics_Low";
                            }
                            else if (_Orthopedics > 5 && _Orthopedics <= 10)
                            {
                                _OrthopedicsStatus = "Orthopedics_Medium";
                            }
                            else if (_Orthopedics > 10)
                            {
                                _OrthopedicsStatus = "Orthopedics_High";
                            }

                            _data += _OrthopedicsStatus + ",";
                        }

                        if (tabDataset.Rows[i]["Surgeon"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Surgeon
                            double _Surgeon = double.Parse(tabDataset.Rows[i]["Surgeon"].ToString());
                            string _SurgeonStatus = null;

                            if (_Surgeon <= 5)
                            {
                                _SurgeonStatus = "Surgeon_Low";
                            }
                            else if (_Surgeon > 5 && _Surgeon <= 10)
                            {
                                _SurgeonStatus = "Surgeon_Medium";
                            }
                            else if (_Surgeon > 10)
                            {
                                _SurgeonStatus = "Surgeon_High";
                            }

                            _data += _SurgeonStatus + ",";
                        }

                        if (tabDataset.Rows[i]["Physician"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Physician
                            double _Physician = double.Parse(tabDataset.Rows[i]["Physician"].ToString());
                            string _PhysicianStatus = null;

                            if (_Physician <= 5)
                            {
                                _PhysicianStatus = "Physician_Low";
                            }
                            else if (_Physician > 5 && _Physician <= 10)
                            {
                                _PhysicianStatus = "Physician_Medium";
                            }
                            else if (_Physician > 10)
                            {
                                _PhysicianStatus = "Physician_High";
                            }

                            _data += _PhysicianStatus + ",";
                        }
                        if (tabDataset.Rows[i]["Beds"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Beds
                            double _Beds = double.Parse(tabDataset.Rows[i]["Beds"].ToString());
                            string _BedsStatus = null;

                            if (_Beds <= 25)
                            {
                                _BedsStatus = "Beds_Low";
                            }
                            else if (_Beds > 25 && _Beds <= 50)
                            {
                                _BedsStatus = "Beds_Medium";
                            }
                            else if (_Beds > 50)
                            {
                                _BedsStatus = "Beds_High";
                            }

                            _data += _BedsStatus + ",";
                        }

                        if (tabDataset.Rows[i]["ICU"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //ICU
                            double _ICU = double.Parse(tabDataset.Rows[i]["ICU"].ToString());
                            string _ICUStatus = null;

                            if (_ICU <= 10)
                            {
                                _ICUStatus = "ICU_Low";
                            }
                            else if (_ICU > 10 && _ICU <= 20)
                            {
                                _ICUStatus = "ICU_Medium";
                            }
                            else if (_ICU > 20)
                            {
                                _ICUStatus = "ICU_High";
                            }

                            _data += _ICUStatus + ",";
                        }

                        if (tabDataset.Rows[i]["Nurses"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Nurses
                            double _Nurses = double.Parse(tabDataset.Rows[i]["Nurses"].ToString());
                            string _NursesStatus = null;

                            if (_Nurses <= 20)
                            {
                                _NursesStatus = "Nurses_Low";
                            }
                            else if (_Nurses > 20 && _Nurses <= 40)
                            {
                                _NursesStatus = "Nurses_Medium";
                            }
                            else if (_Nurses > 40)
                            {
                                _NursesStatus = "Nurses_High";
                            }

                            _data += _NursesStatus + ",";
                        }

                        //if (tabDataset.Rows[i]["Dentist"].ToString().Equals(""))
                        //{

                        //}
                        //else
                        //{
                        //    //Dentist
                        //    double _Dentist = double.Parse(tabDataset.Rows[i]["Dentist"].ToString());
                        //    string _DentistStatus = null;

                        //    if (_Dentist <= 5)
                        //    {
                        //        _DentistStatus = "Dentist_Low";
                        //    }
                        //    else if (_Dentist > 5 && _Dentist <= 10)
                        //    {
                        //        _DentistStatus = "Dentist_Medium";
                        //    }
                        //    else if (_Dentist > 10)
                        //    {
                        //        _DentistStatus = "Dentist_High";
                        //    }

                        //    _data += _DentistStatus + ",";
                        //}

                        //if (tabDataset.Rows[i]["Pharmacy"].ToString().Equals(""))
                        //{

                        //}
                        //else
                        //{
                        //    //Pharmacy
                        //    double _Pharmacy = double.Parse(tabDataset.Rows[i]["Pharmacy"].ToString());
                        //    string _PharmacyStatus = null;

                        //    if (_Pharmacy <= 2)
                        //    {
                        //        _PharmacyStatus = "Pharmacy_Low";
                        //    }
                        //    else if (_Pharmacy > 2 && _Pharmacy <= 4)
                        //    {
                        //        _PharmacyStatus = "Pharmacy_Medium";
                        //    }
                        //    else if (_Pharmacy > 5)
                        //    {
                        //        _PharmacyStatus = "Pharmacy_High";
                        //    }

                        //    _data += _PharmacyStatus + ",";
                        //}

                        //if (tabDataset.Rows[i]["TechnicalNurses"].ToString().Equals(""))
                        //{

                        //}
                        //else
                        //{
                        //    //Neurologist
                        //    double _TechnicalNurses = double.Parse(tabDataset.Rows[i]["TechnicalNurses"].ToString());
                        //    string _TechnicalNursesStatus = null;

                        //    if (_TechnicalNurses <= 15)
                        //    {
                        //        _TechnicalNursesStatus = "TechnicalNurses_Low";
                        //    }
                        //    else if (_TechnicalNurses > 15 && _TechnicalNurses <= 30)
                        //    {
                        //        _TechnicalNursesStatus = "TechnicalNurses_Medium";
                        //    }
                        //    else if (_TechnicalNurses > 30)
                        //    {
                        //        _TechnicalNursesStatus = "TechnicalNurses_High";
                        //    }

                        //    _data += _TechnicalNursesStatus + ",";
                        //}

                        if (tabDataset.Rows[i]["MortalityRate"].ToString().Equals(""))
                        {

                        }
                        else
                        {
                            //Neurologist
                            double _MortalityRate = double.Parse(tabDataset.Rows[i]["MortalityRate"].ToString());
                            string _MortalityRateStatus = null;

                            if (_MortalityRate < 7)
                            {
                                _MortalityRateStatus = "MortalityRate_Low";
                            }
                            else if (_MortalityRate >= 7 && _MortalityRate < 8)
                            {
                                _MortalityRateStatus = "MortalityRate_Medium";
                            }
                            else if (_MortalityRate >= 8)
                            {
                                _MortalityRateStatus = "MortalityRate_High";
                            }

                            _data += _MortalityRateStatus + ",";
                        }

                        lv_Transactions.Items.Add(_data.Substring(0, _data.Length - 1));

                        //code to identify the distinct items
                        string[] items = null;
                        items = lv_Transactions.Items[i].Text.Split(',');

                        for (int w = 0; w < items.Length; w++)
                        {
                            ListItem item = new ListItem();
                            item.Text = items[w];

                            if (lv_Items.Items.Contains(item))
                            {

                            }
                            else
                            {
                                if (item.Text.Equals(""))
                                {

                                }
                                else
                                {
                                    lv_Items.Items.Add(items[w]);
                                }

                            }
                        }
                    }

                    var watch = System.Diagnostics.Stopwatch.StartNew();

                    Solve();

                    watch.Stop();
                    var elapsedMs = watch.ElapsedMilliseconds;
                    _time = elapsedMs.ToString();

                    lblTime.Text = string.Empty;
                    lblTime.ForeColor = System.Drawing.Color.Red;
                    lblTime.Font.Bold = true;
                    lblTime.Text = "Execution Time: " + _time + " milliseconds";

                    Session["A_Time"] = null;
                    Session["A_Time"] = _time;
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Dataset Not Found!!!')</script>");
                }

            }
            catch
            {

            }
        }            

    }
}